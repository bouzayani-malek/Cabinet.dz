 <?php
session_start();
					
																										//db details
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'cabinet';

//Connect and select the database
$db =  mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
	                                $delete=$_POST['etatt'];
									
								    	$SQLL="DELETE FROM `rdv` WHERE id_rdv=$delete";
			                            mysqli_query($db,$SQLL);
										header("location:afficherdvmed.php");
							
					 
				?>