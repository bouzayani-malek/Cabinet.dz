<?php 

    session_start();

//db details
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'cabinet';

//Connect and select the database
$db =  mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);

//selection du base de donner 
  //$requete ="SELECT * FROM `users`";
  //$resultat=mysqli_query($db,$requete);							
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>La liste des patients</title>
    <!-- Bootstrap Styles-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FontAwesome Styles-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- Morris Chart Styles-->
    <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
    <!-- Custom Styles-->
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
    <!-- Google Fonts-->   
     <link rel="stylesheet" type="text/css" href="style.css">  
</head>

<body>
    <div id="wrapper">
	
	
	
        <nav class="navbar navbar-default top-navbar" role="navigation">
		
		 <nav class="navbar navbar-default top-navbar" role="navigation">
		
		

            <ul class="nav navbar-top-links navbar-right">
			
			
                <!-- /user -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        
                        <li><a href="setting.php"><i class="fa fa-gear fa-fw"></i> Réglage</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="index.php"><i class="fa fa-sign-out fa-fw"></i> Déconnexion</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
				
				
				
               
            </ul>
        </nav>
		
        </nav>
		
		
		
		
		 <!--/. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
		
            <div class="sidebar-collapse">
			
			
                <ul class="nav" id="main-menu">
				
				
				
				  
					
					
					<li>
                        <a href="#">Médecins<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          
                            
                            <li>
                               <a href="affichemedecin.php">La liste les médecins</a>
                                

                            </li>
                        </ul>
                    </li>
					<li>
                        <a href="#">Patients<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          
                            
                            <li>
                               <a href="afficheusers.php">La liste des patients</a>
                          
                                

                            </li>
                        </ul>
                    </li>
                   

                <li>
                        <a href="#">Services<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="ajoutservice.php">Ajouter des services</a>
                            </li>
                             
                            <li>
                                <a href="afficheservice.php">Afficher les services</a>
                                

                            </li>
                        </ul>
                    </li>
 <li>
                        <a href="#">Spécialité<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="ajoutspecialite.php">Ajouter des spécialités</a>
                            </li>
                             
                            <li>
                                <a href="affichespecialite.php"> Afficher les spécialités</a>
                                

                            </li>
                        </ul>
                    </li>
                    
                </ul>



            </div>

        </nav>
		
		
		
		
		
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                 <div class="row">
                    <div class="col-md-12">
                        <br>
                        <h1 class="page-header" style="text-align : center ; color: #ffffff; font-weight: bold; font-size: 40px;">
                         Les patients:
                        </h1>
                    </div>
                </div> 
				
				
				<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">	
                        <div class="panel-body">
                            <div class="row">			
                                <div class="col-lg-6">						
                                    <form method="post" action="" >								
                                        <div class="form-group">
                                            <label>Nom: </label>
                                            <input class="form-control" type="text" name="nom">                             
                                        </div>
										<center>
                                        <button type="submit" class="btn btn-default" name="ajouter" style="color: #fff; background:#7eced5;">Chercher</button>
                                        </center>										
                                    </form>								
                                </div>								
                            </div>                           
                        </div>                      					
					</div>                 
                </div>            
            </div>
				
				<?php 
			if (!($_SERVER["REQUEST_METHOD"] == "POST")){
				$requete ="SELECT * FROM `infousers`";
                $resultat=mysqli_query($db,$requete);		
			
			?>
				
				
				
                <div class="row">
                   
                    <div class="col-md-8 col-sm-12 col-xs-12">

                        <div class="panel panel-default">
                            
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered table-hover">
                                        <thead>
                                            <tr>
											    <th style="color: red; font-size: 15px;  ">Image:</th>
                                                <th style="color: red; font-size: 15px;  ">Nom:</th>
												
                                                <th style="color: red; font-size: 15px;  ">Téléphone:</th>
                                                <th style="color: red; font-size: 15px;  ">Adresse:</th>
												<th style="color: red; font-size: 15px;  ">Région:</th>
                                                <th style="color: red; font-size: 15px;  ">Email:</th>
												<th style="color: red; font-size: 15px;  ">action:</th>
                                                
											  
												
                                            </tr>
                                        </thead>
                                        <tbody>
								<?php while ($ligne=mysqli_fetch_array($resultat)){ ?>
                                            <tr>
                                                											
                                                <td><img src="works/<?php echo $ligne['image'] ?>" alt="" width="100%"  /></td>
                                                <td><?php echo $ligne['nom']." ".$ligne['prenom']; ?></td>
												<?php $id=$ligne['id_info'] ?>
												<td><?php echo $ligne['telephone'] ?></td>
												<td><?php echo $ligne['adresse'] ?></td>
												<td><?php echo $ligne['region'] ?></td>
												<td><?php echo $ligne['email'] ?></td>
                                                 <td>
												 <a href="usersrdv.php?id=<?php echo$id;?>">rdv</a></td>
                                              
                                                
											
											
                                            </tr>
                                           <?php } ?>   
                                            
                                            

                                        </tbody>
                                    </table>
									
									  
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
				
				
				<?php 
			}if ($_SERVER["REQUEST_METHOD"] == "POST"){
		         @$nom=$_POST['nom'];
			
				 $requete3="SELECT * FROM `infousers` WHERE nom='$nom'";
                $resultat3=mysqli_query($db,$requete3);	
		?>
                     <div class="row">
                   
                    <div class="col-md-8 col-sm-12 col-xs-12">

                        <div class="panel panel-default">
                            
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered table-hover">
                                        <thead>
                                             <tr>
											    <th style="color: red; font-size: 15px;  ">Image:</th>
                                                <th style="color: red; font-size: 15px;  ">Nom:</th>
												
                                                <th style="color: red; font-size: 15px;  ">Téléphone:</th>
                                                <th style="color: red; font-size: 15px;  ">Adresse:</th>
												<th style="color: red; font-size: 15px;  ">Région:</th>
                                                <th style="color: red; font-size: 15px;  ">Email:</th>
                                                <th style="color: red; font-size: 15px;  ">action:</th>
                                                
											  
												
                                            </tr>
                                        </thead>
                                        <tbody>
								<?php while ($ligne=mysqli_fetch_array($resultat3)){ ?>
                                            <tr>
                                                											
                                                <td><img src="works/<?php echo $ligne['image'] ?>" alt="" width="100%"  /></td>
                                                <td><?php echo $ligne['nom']." ".$ligne['prenom']; ?></td>
												<?php $id=$ligne['id_info'] ?>
												<td><?php echo $ligne['telephone'] ?></td>
												<td><?php echo $ligne['adresse'] ?></td>
												<td><?php echo $ligne['region'] ?></td>
												<td><?php echo $ligne['email'] ?></td>
                                              <td>
												 <a href="usersrdv.php?id=<?php echo$id;?>">rdv</a></td>
                                              
                                                
											
											
                                            </tr>
                                           <?php } ?>   
                                            
                                            

                                        </tbody>
                                    </table>
									
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
				<?php 
			}
								
								?>
			
		
				
				
        
			
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
	 
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- Morris Chart Js -->
    <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/js/morris/morris.js"></script>
	
	
	<script src="assets/js/easypiechart.js"></script>
	<script src="assets/js/easypiechart-data.js"></script>
	
	 <script src="assets/js/Lightweight-Chart/jquery.chart.js"></script>
	
    <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
 

</body>

</html>