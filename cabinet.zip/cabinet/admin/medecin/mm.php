<?php 
session_start();
				$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'cabinet';

//Connect and select the databas,e
$db =  mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
					
	//se
	$re="SELECT * FROM `medecin` WHERE id_medecin=$_SESSION[id] ";
  $res=mysqli_query($db,$re);		
  while ($l=mysqli_fetch_array($res)){
	  $email=$l['email'];
  }
                           if(isset($_POST['send'])){ 
						            $pass=$_POST["pass"];
								    $passe=$_POST["passe"];
									$mail=$_POST["mail"];
											if ($email!=$mail){
												header("location:modpassemed.php?error");
											}else if ($passe!=$pass){
												header("location:modpassemed.php?s");
											}else{
												$passe=md5($passe);
												 $SQL="UPDATE `medecin` SET `passe`='$passe'WHERE id_medecin=$_SESSION[id]";
			                         mysqli_query($db,$SQL); 
									header("location:../index.php");
											}	      									 
									
								}
									
									
									
									
									?>