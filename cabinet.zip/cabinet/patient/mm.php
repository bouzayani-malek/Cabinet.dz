<?php 
session_start();
				$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'cabinet';

//Connect and select the databas,e
$db =  mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
					
	//se
	$re="SELECT * FROM `infousers` WHERE id_info=$_SESSION[patient] ";
  $res=mysqli_query($db,$re);		
  while ($l=mysqli_fetch_array($res)){
	  $email=$l['email'];
  }
                           if(isset($_POST['send'])){ 
						            $pass=$_POST["pass"];
								    $passe=$_POST["passe"];
									$mail=$_POST["mail"];
											if ($email!=$mail){
												header("location:modpasse.php?error");
											}else if ($passe!=$pass){
												header("location:modpasse.php?s");
											}else{
												$passe=md5($passe);
												 $SQL="UPDATE `infousers` SET `passe`='$passe'WHERE id_info=$_SESSION[patient]";
			                         mysqli_query($db,$SQL); 
									header("location:../login.php");
											}	      									 
									
								}
									
									
									
									
									?>