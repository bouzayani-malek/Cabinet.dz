<?php 
session_start();
																			//db details
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'cabinet';

//Connect and select the database
$db =  mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
			
								
									$delete=$_GET['id'];
									
								    	$SQ="DELETE FROM `rdv` WHERE id_seance=$delete";
			                            mysqli_query($db,$SQ);
										$SQL="DELETE FROM `seance` WHERE id_seance=$delete";
			                            mysqli_query($db,$SQL);
								header("location:afficheseancemed.php?m=1");
								
									?>