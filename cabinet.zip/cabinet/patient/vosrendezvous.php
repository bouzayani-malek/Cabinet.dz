<?php

    session_start();

				 //db details
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'cabinet';

//Connect and select the database
$db =  mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<meta charset="utf-8">
		
		<title>Patient</title>
		
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.0-2/css/all.min.css">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" charset="utf-8"></script>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>

		<!--wrapper start-->
		<div class="wrapper">
			<!--header menu start-->
			<div class="header">
				<div class="header-menu">
					<div class="title"><span>PATIENT</span></div>
					<div class="sidebar-btn">
						<i class="fas fa-bars"></i>
					</div>
					<ul>
						
						
						<li><a href="../login.php"><i class="fas fa-power-off"></i></a></li>
					</ul>
				</div>
			</div>
			<!--header menu end-->
			
			
			
			<!--sidebar start-->
			<div class="sidebar">
				<div class="sidebar-menu">
				
				<?php 
				$con=mysqli_connect("localhost","root","");
                       
                        // Select the database to use
                        mysqli_select_db($con,'cabinet');
                     $result = mysqli_query($con,"SELECT * FROM infousers where id_info='".$_SESSION["patient"]."';") ;
					 while($row = mysqli_fetch_array($result)){
				?>
					<center class="profile">
						<img src="works/<?php echo $row['image']; ?>" alt="">
						<p><?php echo $row['nom']; ?></p>
					</center>
					
					 <?php }?>
				
					
					
					<li class="item" id="profile">
						<a href="#profile" class="menu-btn">
							<i class="fas fa-user-circle"></i>
							<span>Profil <i class="fas fa-chevron-down drop-down"></i></span>
						</a>
						<div class="sub-menu">
					
							<a href="profil.php"><i class="fas fa-address-card"></i><span>Votre profil</span></a>
						</div>
					</li>
					
					<li class="item" id="rend">
						<a href="#rend" class="menu-btn">
							<i class="fas fa-ambulance"></i>
							<span>Rendez-vous <i class="fas fa-chevron-down drop-down"></i></span>
						</a>
						<div class="sub-menu">
							<a href="vosrendezvous.php"><i class="fas fa-bible"></i><span>Vos rendez_vous</span></a>
	
						</div>
					</li>
					
					
					
					
					<li class="item" id="profi">
						<a href="#profi" class="menu-btn">
							<i class="fas fa-briefcase-medical"></i>
							<span>Prendre un RDV<i class="fas fa-chevron-down drop-down"></i></span>
						</a>
						<div class="sub-menu">
							<a href="rdv.php"><i class="fas fa-male"></i><span>La liste des médecins</span></a>
														<a href="ord.php"><i class="fas fa-chevron-down drop-down"></i><span> vos ordonnances</span></a>

						</div>
					</li>
					
					
					
					
					<li class="item" id="settings">
						<a href="#settings" class="menu-btn">
							<i class="fas fa-cog"></i>
							<span>Paramètres <i class="fas fa-chevron-down drop-down"></i></span>
						</a>
						<div class="sub-menu">
							<a href="modpasse.php"><i class="fas fa-lock"></i><span>Modifier votre mot de passe</span></a>
							<a href="changeprof.php"><i class="fas fa-language"></i><span>Modifier votre profil</span></a>
						</div>
					</li>
					
					
					
				</div>
			</div>
			<!--sidebar end-->
			
			
			
			
			<!--main container start-->
			<div class="main-container">
				
				<div class="card">
			<center>
					
				
				
				
				
				</center/>
				<?php 
		
													//db details
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'cabinet';

//Connect and select the database
$db =  mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
				//selection du base de donner 
                 //  $requete ="SELECT * FROM `rdv` WHERE id_medecin=$_SESSION[id] AND etat='F'";
                  // $resultat=mysqli_query($db,$requete);			
			      $requete ="SELECT * FROM `rdv` WHERE id_info=$_SESSION[patient]";
                     $result=mysqli_query($con,$requete);	
			?>
				<br/><br/>
				<br>
								<br>
								<br>
								<br>
								
							
								<center>
				 <h1 style="color: #1d6775;">Vos rendez vous:</h1><br><br>
                  <table width="80%" border="0" >
                                       
                                            <tr>
											
                                               
												<th style ="color : red; text-align:center;">Séance:</th>
												<th style ="color : red; text-align:center;">Médecin:</th>
												<th style ="color : red; text-align:center;">Spécialité:</th>
												<th style ="color : red; text-align:center;">Date:</th>
												<th style ="color : red; text-align:center;">Annuler:</th>
												<th style ="color : red; text-align:center;">Accepter:</th>
												
                                                
                                                
												
                                            </tr>
											<?php
											 while($ligne = mysqli_fetch_array($result)){?>
						   <tr><?php   if ($ligne['etat']=='F'){
							   
										 $id=$ligne['id_rdv'];
										 $requete2 ="SELECT * FROM `seance` WHERE id_seance=$ligne[id_seance]";
										 $resultat2=mysqli_query($con,$requete2);
										 while ($ligne2=mysqli_fetch_array($resultat2)){
											 
											 
											 
												echo "<td>{$ligne2['nom_seance']}";
												$seance=$ligne2['id_medecin'];$idd=$ligne['date'] ;?>
												<br>
												<a style="color: #7eced5;"href="modsea.php?id=<?php echo $idd;?>&idd=<?php echo $seance;?>&i=<?php echo $id;?>">Modifier</a>
												<?php
												
												$requete3 ="SELECT * FROM `medecin` WHERE id_medecin=$seance";
										        $resultat3=mysqli_query($con,$requete3);
												while ($ligne3=mysqli_fetch_array($resultat3)){
													echo "</td><td>{$ligne3['nom']} {$ligne3['prenom']}";
													
													$requete4="SELECT * FROM `specialite` WHERE id_spe=$ligne3[id_spe]";
										            $resultat4=mysqli_query($con,$requete4);
													
													while ($ligne4=mysqli_fetch_array($resultat4)){
													echo "</td><td>{$ligne4['nom_spe']}";
													
												}}
												
												}?>
                                        <?php ?>
												
												</td>
												<td><?php echo $idd;?>
												<br>
												<a style="color: #7eced5;" href="moddat.php?id=<?php echo $id;?>" >Modifier</a>
												</td>
												<td>
												<form action="p.php" method="post">							  
							                 	<input type="image" src="works/sup.jpg" name="etat"  width="50px" height="50px" />	
							    	            <input type="hidden" name="etatt" value="<?php echo $id ?>" />
								                </form>
												</td>
												<td>
  												<?php
													echo "<p style='color: red;'>NON</p>";
												
												


												?>
												</td>
												<?php
										 }else
												{
												$id=$ligne['id_rdv'];
										 $requete2 ="SELECT * FROM `seance` WHERE id_seance=$ligne[id_seance]";
										 $resultat2=mysqli_query($con,$requete2);
										 while ($ligne2=mysqli_fetch_array($resultat2)){
											 
											 
											 
												echo "<td>{$ligne2['nom_seance']}";
												$seance=$ligne2['id_seance'];$idd=$ligne['date'] ;?>
												<br>
												<?php
												
												$requete3 ="SELECT * FROM `medecin` WHERE id_medecin=$ligne2[id_medecin]";
										        $resultat3=mysqli_query($con,$requete3);
												while ($ligne3=mysqli_fetch_array($resultat3)){
													echo "</td><td>{$ligne3['nom']} {$ligne3['prenom']}";
													
													$requete4="SELECT * FROM `specialite` WHERE id_spe=$ligne3[id_spe]";
										            $resultat4=mysqli_query($con,$requete4);
													
													while ($ligne4=mysqli_fetch_array($resultat4)){
													echo "</td><td>{$ligne4['nom_spe']}";
													
												}}
												
												}?>
                                        <?php ?>
												
												</td>
												<td><?php echo $idd;?>
												<br>
												</td>
												<td>
												<form action="p.php" method="post">							  
							                 	<input type="image" src="works/sup.jpg" name="etat"  width="50px" height="50px" />	
							    	            <input type="hidden" name="etatt" value="<?php echo $id ?>" />
								                </form>
												</td>
												<td>
  												<?php
													echo "<p style='color: red;'>OUI</p>";
												
												


												?>
												</td>
												<?php
										 }
















												?>
												</tr>
										
                              <?php   }
				
							 
            ?>
                                            

                                        
                                    </table>
									
				
				</center>
					<p></p>
				</div>
			</div>
			<!--main container end-->
		</div>
		<!--wrapper end-->

		<script type="text/javascript">
		$(document).ready(function(){
			$(".sidebar-btn").click(function(){
				$(".wrapper").toggleClass("collapse");
			});
		});
		</script>

	</body>
</html>
