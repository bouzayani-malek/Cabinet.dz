 <?php
session_start();
					
																										//db details
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'cabinet';

//Connect and select the database
$db =  mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
	                                 $etat=$_POST['hiddenetat'];					 
									 $nombre=$_POST['hid'];
									 $ss=$_POST['hidd'];
									 $mess=$_POST['hiddd'];
									 
                                   //  $user=$_SESSION["uname"];									 
								     $SQL="UPDATE `rdv` SET `etat`='T' WHERE id_rdv=$etat";
			                         mysqli_query($db,$SQL);
									 $SQ="UPDATE `seance` SET `nombre`=$nombre WHERE id_seance=$ss";
									 mysqli_query($db,$SQ);
								    $sql="INSERT INTO `message`( `message`, `user`, `id_info`, `id_medecin`) VALUES ('bonjour, votre rendez-vous a été accepté','$_SESSION[name]',$mess ,$_SESSION[id])";
					                  mysqli_query($db,$sql);
									//echo $sql;
										header("location:afficherdvmed.php");
							
					 
				?>