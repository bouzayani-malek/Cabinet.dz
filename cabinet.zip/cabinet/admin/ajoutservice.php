<?php 

    session_start();

//db details
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'cabinet';

//Connect and select the database
$db =  mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
if($_POST){
	//recuperer les donnees
                                    @$nom=$_POST["nom_service"];
									@$Des=$_POST["des"];
									@$image=$_POST["image"];


									
//Sinsertion des donners
$req="INSERT INTO `service`(`nom_service`, `descriptions`,`image`, `id_ad`) VALUES ('".mysqli_real_escape_string($db ,$_POST['nom_service'])."','".mysqli_real_escape_string($db ,$_POST['des'])."','$image',$_SESSION[medecin])";
$res=mysqli_query($db,$req);


}									
?>

<!DOCTYPE html>
<html>
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Ajouter  des services</title>
	<!-- Bootstrap Styles-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FontAwesome Styles-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- Custom Styles-->
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
     <!-- Google Fonts-->
      <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default top-navbar" role="navigation">
            <nav class="navbar navbar-default top-navbar" role="navigation">
		
		

            <ul class="nav navbar-top-links navbar-right">
			
			
                <!-- /user -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        
                        <li><a href="setting.php"><i class="fa fa-gear fa-fw"></i> Réglages</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="index.php"><i class="fa fa-sign-out fa-fw"></i>Déconnexion</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
				
				
				
               
            </ul>
        </nav>
		
        </nav>
		
		
		 <!--/. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
		
            <div class="sidebar-collapse">
			
			
                <ul class="nav" id="main-menu">
				
				
				
				  
					
					
					<li>
                        <a href="#">Médecins<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          
                            
                            <li>
                               <a href="affichemedecin.php">La liste des médecins</a>
                                

                            </li>
                        </ul>
                    </li>
					<li>
                        <a href="#">Patients<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          
                            
                            <li>
                               <a href="afficheusers.php">La liste des patients</a>
                          
                                

                            </li>
                        </ul>
                    </li>
                   

                <li>
                        <a href="#">Services<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="ajoutservice.php">Ajouter des services</a>
                            </li>
                             
                            <li>
                                <a href="afficheservice.php"> Afficher les services</a>
                                

                            </li>
                        </ul>
                    </li>
                     <li>
                        <a href="#">Spécialités<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="ajoutspecialite.php">Ajouter des spécialités</a>
                            </li>
                             
                            <li>
                                <a href="affichespecialite.php"> Afficher les spécialités</a>
                                

                            </li>
                        </ul>
                    </li>
                </ul>



            </div>

        </nav>
		
		
		
		
        <div id="page-wrapper" >
            <div id="page-inner">
			
			
			 <div class="row">
                    <div class="col-md-12">
                        <br>
                        <h1 class="page-header" style="text-align : center ; color: #ffffff; font-weight: bold; font-size: 40px;">
                         Ajouter des services:  
                        </h1>
                    </div>
                </div> 
				
				
                 <!-- /. ROW  -->
              <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
					
					
                        
						
						
                        <div class="panel-body">
                            <div class="row">
							
							
                                <div class="col-lg-6">
								
								
								
                                    <form role="form" name="service" method="post" action="">
									
                                        <div class="form-group">
                                            <label  style="color: red; font-size: 15px;  ">Nom de service: </label>
                                            <br>
                                            <input class="form-control" placeholder="Nom" name="nom_service" >                             
                                        </div>
                                        <br>
										
                                        <div class="form-group">
                                            <label  style="color: red; font-size: 15px;  ">Image: </label>
                                            <br>
                                            <input type="file"  name="image" >                             
                                        </div>
                                        <br>
										
                                        
										<div class="form-group">
                                            <label  style="color: red; font-size: 15px;  ">Déscription : </label>
                                            <br>
                                            <textarea class="form-control" rows="5" placeholder="Description" name="des"></textarea>
                                        </div>
                                        <br>
										 
										
									
										<center>
                                        <button type="submit" class="btn btn-default" name="ajoute" style="color: #fff; background:#7eced5;">Ajouter</button>
                                        </center>
										
                                    </form>
                                    <br>
									
                                </div>
								
								
								
                                <!-- /.col-lg-6 (nested) -->
                                
                                <!-- /.col-lg-6 (nested) -->
								
                            </div>
                            
                        </div>
                       
                    
					
					</div>
                    
                </div>
               
            </div>
			
			
		
			
			
			</div>
             <!-- /. PAGE INNER  -->
            </div>
			
			
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
    
   
</body>
</html>
