<?php
session_start();
					
																										//db details
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'cabinet';

//Connect and select the database
$db =  mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
	 
									$dd=$_POST['hid'];
									 $ii=$_POST['hidd'];
									 //$iii=$_POST['hiddd'];
							echo $dd;
                     $req="INSERT INTO `rdv`( `date`, `etat`, `id_seance`, `id_info`) VALUES ('$dd','F',$ii,$_SESSION[patient])";
                     $res=mysqli_query($db,$req);
$_SESSION['malek']=1;					 
header("location:vous.php?id=$_POST[hiddd]");
					 
				?>