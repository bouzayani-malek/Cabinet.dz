 <?php
session_start();
					
																										//db details
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'cabinet';

//Connect and select the database
$db =  mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
					  $delete=$_POST['hiddenetat'];
										
										$se="SELECT * FROM `medecin` WHERE id_spe=$delete";
										 $resu=mysqli_query($db,$se);
										 
										 while ($li=mysqli_fetch_array($resu)){
											 
											 $s="DELETE FROM `ordonnance` WHERE id_medecin=$li[id_medecin] ";
										       mysqli_query($db,$s);
											 $ss="DELETE FROM `message` WHERE id_medecin=$li[id_medecin] ";
										       mysqli_query($db,$ss);
											   
											   $sss="SELECT * FROM `seance` WHERE id_medecin=$li[id_medecin]";
									        	 $res=mysqli_query($db,$sss);
											 while ($l=mysqli_fetch_array($res)){
											     $ssss="DELETE FROM `rdv` WHERE id_seance=$l[id_seance]" ;
											    mysqli_query($db,$ssss);
										 }
											$sssss="DELETE FROM `seance` WHERE id_medecin=$li[id_medecin] ";
									     	mysqli_query($db,$sssss);
											
										 }
										
										
								    	$SQL="DELETE FROM `specialite` WHERE id_spe=$delete";
			                            mysqli_query($db,$SQL);
										header("location:affichespecialite.php");
				?>