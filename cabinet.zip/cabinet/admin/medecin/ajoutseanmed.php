<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<meta charset="utf-8">
		<title>Médecin</title>
		
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.0-2/css/all.min.css">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" charset="utf-8"></script>
   <link rel="stylesheet" type="text/css" href="stylee.css">	
	</head>
	<body>

		<!--wrapper start-->
		<div class="wrapper">
			<!--header menu start-->
			<div class="header">
				<div class="header-menu">
					<div class="title"><span>Médecin</span></div>
					<div class="sidebar-btn">
						<i class="fas fa-bars"></i>
					</div>
					<ul>
						
					<li><a href="../index.php"><i class="fas fa-power-off"></i></a></li>
					</ul>
				</div>
			</div>
			<!--header menu end-->
			
			
			
			<!--sidebar start-->
			<div class="sidebar">
				<div class="sidebar-menu">
				
				<?php 
				$con=mysqli_connect("localhost","root","");
                       
                        // Select the database to use
                        mysqli_select_db($con,'cabinet');
                     $result = mysqli_query($con,"SELECT * FROM medecin where id_medecin='".$_SESSION["id"]."';") ;
					 while($row = mysqli_fetch_array($result)){
				?>
					<center class="profile">
						<img src="works/<?php echo $row['image']; ?>" alt="">
						<p style="color:#fff;"><?php echo $row['nom']; ?></p>
					</center>
					
					 <?php }?>
				
					
					
					<li class="item" id="profile">
            <a href="#profile" class="menu-btn">
              <i class="fas fa-user-circle"></i>
              <span>Profil <i class="fas fa-chevron-down drop-down"></i></span>
            </a>
            <div class="sub-menu">
          
              <a href="profilmed.php"><i class="fas fa-address-card"></i><span>Votre profil</span></a>
            </div>
          </li>
          
          <li class="item" id="rend">
            <a href="#rend" class="menu-btn">
              <i class="fas fa-ambulance"></i>
              <span>Rendez-vous <i class="fas fa-chevron-down drop-down"></i></span>
            </a>
            <div class="sub-menu">
              <a href="ajoutseanmed.php"><i class="fas fa-ad"></i><span>Ajouter des séances</span></a>
              <a href="afficheseancemed.php"><i class="fas fa-book-reader"></i><span>Afficher les séances</span></a>
              <a href="afficherdvmed.php"><i class="fas fa-bible"></i><span> La liste des rendez-vous</span></a>
              <a href="afficherdvacceptermed.php"><i class="fas fa-check"></i><span>Les rendez-vous accéptés</span></a>
            </div>
          </li>
          
          
          
          
          <li class="item" id="profi">
            <a href="#profi" class="menu-btn">
              <i class="fas fa-briefcase-medical"></i>
              <span> Les patients<i class="fas fa-chevron-down drop-down"></i></span>
            </a>
            <div class="sub-menu">
              <a href="malademed.php"><i class="fas fa-male"></i><span>La liste des patients</span></a>
              
            </div>
          </li>
          
        
          
          
          <li class="item" id="settings">
            <a href="#settings" class="menu-btn">
              <i class="fas fa-cog"></i>
              <span>Paramètres <i class="fas fa-chevron-down drop-down"></i></span>
            </a>
            <div class="sub-menu">
              <a href="modpassemed.php"><i class="fas fa-lock"></i><span>Modifier votre mot de passe</span></a>
              <a href="changeprofmed.php"><i class="fas fa-language"></i><span>Modifier votre profil</span></a>
            </div>
          </li>
          
          
          
        </div>
      </div>
			<!--sidebar end-->
			
			
			
			
			<!--main container start-->
			<div class="main-container">
				
				<div class="card">
				
				<center>
          <br>
          <br>
          <br>
								<br>
								
								
				 <h1 style="color : #1d6775;">Ajouter des séances: </h1><br><br>
         <br>
         <br>

                                    
				       <form role="form"  name="medecin" method="post" action="" >
									
                                        <div class="form-group">
                                            <h5 style="color:red; font-size: 15px; ">Nom de séance: </h5><br/>
                                            <input class="form-control" type="text" placeholder="Nom de séance" name="nom">
                                                                       
                                        </div>
										<br/>
                                        <div class="form-group">
                                            <h5 style="color:red; font-size: 15px;">Heur: </h5><br/><br/>
                                            <input class="form-control" placeholder="Heur"  type="text" name="heur">                             
                                        </div>
										<br/>
                    
										 <div class="form-group">
                                             <h5 style="color:red; font-size: 15px;">Date: </h5><br/><br/>
                                            <input class="form-control" placeholder="Date" type="date" name="date">                             
                                        </div>
										<br/>
                    
										 <div class="form-group">
                                             <h5 style="color:red; font-size: 15px;">Nombre:</h5><br/><br/>
                                            <input class="form-control" placeholder="Nombre" type="text" name="nombre">                             
                                        </div>
                                        <br>
										<br/>
										
                                        <button type="submit" class="btn btn-default" name="ajouter " style="color: #fff; background:#7eced5; ">Ajouter</button>
                                        </center>
										
                                    </form>
									<?php 
									
									
									//db details
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'cabinet';

//Connect and select the database
$db =  mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
if($_POST){
	//recuperer les donnees
                                    @$nom=$_POST["nom"];
									@$heur=$_POST["heur"];
									@$date=$_POST["date"];
									@$nombre=$_POST["nombre"]; 
									
									
//insertion des donners
$req="INSERT INTO `seance`(`nom_seance`, `heur`, `date`, `nombre`, `id_medecin`) VALUES ('$nom','$heur','$date','$nombre',$_SESSION[id])";
$res=mysqli_query($db,$req);


}	
									
									
									
									
									?>
				
				</center>
									
							

					<p></p>
				</div>
			</div>
			<!--main container end-->
		</div>
		<!--wrapper end-->

		<script type="text/javascript">
		$(document).ready(function(){
			$(".sidebar-btn").click(function(){
				$(".wrapper").toggleClass("collapse");
			});
		});
		</script>

	</body>
</html>
