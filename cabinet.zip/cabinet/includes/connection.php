<?php

	$server="localhost";
	$user="root";
	$pass="";
	$db="cabinet";
	
	// connect to mysql
	
	$con = mysqli_connect($server, $user, $pass, $db) ;
	
	

?>