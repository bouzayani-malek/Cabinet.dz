<?php
session_start();
                if (isset($_POST['admin']))
                {   
                    $_SESSION["name"]= $_POST["name"];
                    $_SESSION["pass"]= $_POST["pass"];
                    $username = $_POST["name"];
                    $password = md5($_POST["pass"]);
                    // Connect to the database
                        $con=mysqli_connect("localhost","root","");
                       
                        // Select the database to use
                        mysqli_select_db($con,'cabinet');

                        $result = mysqli_query($con,"SELECT * FROM admin where user='$username' AND passe ='$password' ;") ;

                        $row = mysqli_fetch_array($result);

                        if($row["user"]==$username && $row["passe"]==$password)
                        {
							$_SESSION["medecin"]=$row["id_ad"];
							
							$_SESSION["malek"]=0;
                            header("Location:profil.php");
						     
						
                        }else{
							header("Location:index.php?er");
						}

                        
                }
                    if (isset($_POST['medecin']))
                 {
                     
                    $_SESSION["passe"]= $_POST["pass"];
                    $username = $_POST["name"];
                    $password = $_POST["pass"];
					$Password=md5($password);
                    // Connect to the database
                        $con=mysqli_connect("localhost","root","");
                       
                        // Select the database to use
                        mysqli_select_db($con,'cabinet');

                        $result = mysqli_query($con,"SELECT * FROM medecin where email='".$username."' and passe='".$Password."';") ;

                        $row = mysqli_fetch_array($result);

                        if($row["email"]==$username && $row["passe"]==$Password)
                        {
                           $_SESSION["name"]= $row["nom"];
						$_SESSION["id"]=$row["id_medecin"];
						
							$_SESSION["malek"]=0;
                        header("Location:medecin/profilmed.php");
						//ob_end_flush();
						
                        }else{
							header("location:index.php?er");
						}

                        
                  }
            ?>
			