<?php 

    session_start();

//db details
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'cabinet';

//Connect and select the database
$db =  mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);

//selection du base de donner 
  $requete ="SELECT * FROM `infousers` WHERE id_info=$_GET[idd]";
  $resultat=mysqli_query($db,$requete);							
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Informations</title>
    <!-- Bootstrap Styles-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FontAwesome Styles-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- Morris Chart Styles-->
    <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
    <!-- Custom Styles-->
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
    <!-- Google Fonts-->     
</head>

<body>
    <div id="wrapper">
	
	
	
        <nav class="navbar navbar-default top-navbar" role="navigation">
		
		 <nav class="navbar navbar-default top-navbar" role="navigation">
		
		

            <ul class="nav navbar-top-links navbar-right">
			
			
                <!-- /user -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        
                        <li><a href="setting.php"><i class="fa fa-gear fa-fw"></i> Réglage</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="index.php"><i class="fa fa-sign-out fa-fw"></i> Déconnexion</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
				
				
				
               
            </ul>
        </nav>
		
        </nav>
		
		
		
		<nav class="navbar-default navbar-side" role="navigation">
		
            <div class="sidebar-collapse">
			
			
                <ul class="nav" id="main-menu">
				
				
				
				  
					
					
					<li>
                        <a href="#">Médecin<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          
                            
                            <li>
                               <a href="affichemedecin.php">Voir</a>
                                

                            </li>
                        </ul>
                    </li>
					<li>
                        <a href="#">Utilisateur<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          
                            
                            <li>
                               <a href="afficheusers.php">les comptes des utilisateurs</a>
                          
                                

                            </li>
                        </ul>
                    </li>
                   

                <li>
                        <a href="#">Service<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="ajoutservice.php">Ajouter des services</a>
                            </li>
                             
                            <li>
                                <a href="afficheservice.php">les services</a>
                                

                            </li>
                        </ul>
                    </li>
                     <li>
                        <a href="#">Specialite<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="ajoutspecialite.php">Ajouter des specialites</a>
                            </li>
                             
                            <li>
                                <a href="affichespecialite.php">les specialites</a>
                                

                            </li>
                        </ul>
                    </li>
                </ul>



            </div>

        </nav>
		
		
		
		
		
		
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                 <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header" style="text-align : center">
                         Le profil d'utilisateur:
                        </h1>
                    </div>
                </div> 


				
                
	
			
	   
				
				
				
                <div class="row">
                   
                    <div class="col-md-8 col-sm-12 col-xs-12">

                        <div class="panel panel-default">
                            
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered table-hover">
                                       
								<?php while ($ligne=mysqli_fetch_array($resultat)){ ?>
                                            <tr>
                                                <th>image</th>			
                                                 <td><img src="works/<?php echo $ligne['image'] ?>" alt="" width="25%"  /></td>
                                             <tr/>
                                              <tr>
                                                <th>Nom</th>			
                                                <td><?php echo $ligne['nom'] ?></td>
                                             <tr/>
                                             <tr><th>Prénom</th><td><?php echo $ligne['prenom'] ?></td></tr>
                                             <tr><th>email</th><td><?php echo $ligne['email'] ?></td></tr>
                                             <tr><th>telephone</th><td><?php echo $ligne['telephone'] ?></td></tr> 
                                             <tr><th>adresse</th><td><?php echo $ligne['adresse'] ?></td></tr>
                                             <tr><th>wilaya</th><td><?php echo $ligne['region'] ?></td></tr>
                                                
												
                                                
                                                
                                                
												
                                            </tr>
                                           <?php } ?>   
                                            
                                            

                                        
                                    </table>
									
									 
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- /. ROW  -->
			
		
				
				
        
			
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
	 
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- Morris Chart Js -->
    <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/js/morris/morris.js"></script>
	
	
	<script src="assets/js/easypiechart.js"></script>
	<script src="assets/js/easypiechart-data.js"></script>
	
	 <script src="assets/js/Lightweight-Chart/jquery.chart.js"></script>
	
    <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
 

</body>

</html>