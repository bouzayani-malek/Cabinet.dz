<?php
session_start();
 //db details
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'cabinet';

//Connect and select the database
$db =  mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
?>
<!DOCTYPE html>

<html class="no-js">

<html lang="en-US">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="..........................................................................." />
    <meta name="description" content="........................................................................" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <link rel="shortcut icon" type="image/x-icon" href="favicon.ico..........................................." />
    <link rel="apple-touch-icon" type="image/x-icon" href="apple-touch-icon.png..............................." />
    <title>ordonnance</title>
    <link rel="shortcut icon" href="imge/Graphicloads-Medical-Health-Medicine-box-2.ico">
    <link rel="stylesheet" type="text/css" href="csss/font-awesome.min.css" media="all" />
    <link rel="stylesheet" type="text/css" href="csss/normalize.css" media="all" />
    <link rel="stylesheet" type="text/css" href="csss/bootstrap.css" media="all" />
    <link rel="stylesheet" type="text/css" href="style.css" media="all" />
    <style type="text/css">
        hr {
width: 50%;


margin-right: auto;
margin-left: auto;
margin-top: 5px;
margin-bottom: 5px;
border-width: 2px ;
border-color: green ;
}
    </style>
   
    
    
</head>


<body >


   



<h3 style="margin-left:28%;">Ordonnance</h3>
            
        <center >
            
                

            <form class="col-md-4 col-sm-offset-4 text-center" style="margin: 0%;text-align: center;margin-left: 10%;margin-right: 10%;padding-top: 0%;padding-bottom: 2%;" method="post" action="" >
               
		
		<div class="result_table">
            <table style="background:white;border:1px solid black;" class="text-center">
                <thead>
                    <tr >
                        <th  > 
                            <pre style="text-align: left;">
             Nom de la clinique médicale / Nom de l'etablissement Coordonnées
                        <br>
 <?php  
				
  $requete ="SELECT * FROM `infousers` WHERE id_info=$_GET[idd]";
  $resultat=mysqli_query($db,$requete);	
 while ($ligne=mysqli_fetch_array($resultat)){ 
				 ?>
                    
                        Patient : <?php echo $ligne['nom']." ".$ligne['prenom'];?>  <br/> 
                           
                        Adresse : <?php echo $ligne['adresse'];?>  <br/>
                    
                      Téléphone : <?php echo $ligne['telephone'];?>  <br/>
                        <br>
                                              
<?php } ?>
                                                          <hr style="border: 1px solid black">
                                                          <table>
                                                            <tr>
                                                          <th> <?php
                    
                         

                        $con=mysqli_connect("localhost","root","","cabinet");
                        
                        $requete="SELECT * FROM ordonnance WHERE id_ord=$_GET[ord]";
						
                         $result = mysqli_query($con,$requete);
                                    
						     
            ?>
                         <p style="color:red;margin-left:8%; ">                               Ordonance :</p>
                         <p style="margin-left:25%;margin-right:25%; "><?php while($row = mysqli_fetch_array($result)){
                                                                                              echo $row['ordonnance'];
$date=$row['date'];
                                        
                                }
						     
            ?></p>
                                                               
                
                                                          </th>
                                                          
                                                       </tr>       
                                                           </table>
                                                  Date : <?php echo$date;?>      <br/>
	<?php		
  $requet ="SELECT * FROM `medecin` WHERE id_medecin=$_GET[med]";
  $result=mysqli_query($db,$requet);	
 while ($ligne=mysqli_fetch_array($result)){ 
				 ?>
                           
             Nom de medecin :                        Signature :   
            
             <?php echo $ligne['nom']." ".$ligne['prenom'];?>
                                                              
  <?php } ?>                          
                          </pre>
               
                        </th>
                   
                                  
                        </tr>
                        
                        
                </thead>
                
            </table>
                </div>
            </form>
                
            <br>



    </center>
    
<script>
function myfonction(){
window.print();
}

</script>
</body>

</html>
