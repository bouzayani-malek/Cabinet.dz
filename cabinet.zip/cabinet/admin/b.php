 <?php
session_start();
					
																										//db details
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'cabinet';

//Connect and select the database
$db =  mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
	 
									
										
										
							
					
									    $delete=$_POST['hiddenetat'];
								    	$SQL="DELETE FROM `service` WHERE id_service=$delete";
			                            mysqli_query($db,$SQL);
									 header("location:afficheservice.php");
								
				?>