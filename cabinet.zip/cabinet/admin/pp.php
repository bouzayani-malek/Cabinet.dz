<?php
session_start();
					
																										//db details
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'cabinet';

//Connect and select the database
$db =  mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
	 


									    $delete=$_POST['hiddenetat'];
										
										$s="DELETE FROM `ordonnance` WHERE id_medecin=$delete ";
										 mysqli_query($db,$s);
										 
										$ss="DELETE FROM `message` WHERE id_medecin=$delete ";
										 mysqli_query($db,$ss);
										 
										$sss="SELECT * FROM `seance` WHERE id_medecin=$delete";
										 $resu=mysqli_query($db,$sss);
										 
										 while ($l=mysqli_fetch_array($resu)){
											$ssss="DELETE FROM `rdv` WHERE id_seance=$l[id_seance]" ;
											    mysqli_query($db,$ssss);
										 }
										 
										$sssss="DELETE FROM `seance` WHERE id_medecin=$delete ";
									     	mysqli_query($db,$sssss);
											
								    	$SQL="DELETE FROM `medecin` WHERE id_medecin=$delete";
			                            mysqli_query($db,$SQL);
									 
								header("location:affichemedecin.php");
					 
				?>