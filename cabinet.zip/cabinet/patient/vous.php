<?php
ob_start();
    session_start();
				 //db details
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'cabinet';

//Connect and select the database
$db =  mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<meta charset="utf-8">
		<title>Patient</title>
		
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.0-2/css/all.min.css">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" charset="utf-8"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
		<link rel="stylesheet" type="text/css" href="stylee.css">
	</head>
<?php 	if(($_SESSION['malek']==1)){
	echo '<body  onload="renderDate();bb();">';
	$_SESSION['malek']=0;
}else{
	echo '<body  onload="renderDate();">';
}
?>
		<!--wrapper start-->
		<div class="wrapper">
			<!--header menu start-->
			<div class="header">
				<div class="header-menu">
					<div class="title"><span>PATIENT</span></div>
					<div class="sidebar-btn">
						<i class="fas fa-bars"></i>
					</div>
					<ul>
						
						
						<li><a href="../login.php"><i class="fas fa-power-off"></i></a></li>
					</ul>
				</div>
			</div>
			
			
			<div class="sidebar">
				<div class="sidebar-menu">
				
				<?php 
				$con=mysqli_connect("localhost","root","");                 
                        mysqli_select_db($con,'cabinet');
                     $result = mysqli_query($con,"SELECT * FROM infousers where id_info='".$_SESSION["patient"]."';") ;
					 while($row = mysqli_fetch_array($result)){
				?>
					<center class="profile">
						<img src="works/<?php echo $row['image']; ?>" alt="">
						<p><?php echo $row['nom']; ?></p>
					</center>
					
					 <?php }?>
				
					
					
					<li class="item" id="profile">
						<a href="#profile" class="menu-btn">
							<i class="fas fa-user-circle"></i>
							<span>Profil<i class="fas fa-chevron-down drop-down"></i></span>
						</a>
						<div class="sub-menu">
					
							<a href="profil.php"><i class="fas fa-address-card"></i><span>Votre Profil</span></a>
						</div>
					</li>
					
					<li class="item" id="rend">
						<a href="#rend" class="menu-btn">
							<i class="fas fa-ambulance"></i>
							<span>Rendez_Vous<i class="fas fa-chevron-down drop-down"></i></span>
						</a>
						<div class="sub-menu">
							<a href="vosrendezvous.php"><i class="fas fa-bible"></i><span>Vos rendez-vous</span></a>
	
						</div>
					</li>
					
					
					
					
					<li class="item" id="profi">
						<a href="#profi" class="menu-btn">
							<i class="fas fa-briefcase-medical"></i>
							<span>Prendre un RDV<i class="fas fa-chevron-down drop-down"></i></span>
						</a>
						<div class="sub-menu">
							<a href="rdv.php"><i class="fas fa-male"></i><span>La liste des médecin</span></a>
													<a href="ord.php"><i class="fas fa-chevron-down drop-down"></i><span> Vos ordonnances</span></a>
	
						</div>
					</li>
					
					
					
					
					<li class="item" id="settings">
						<a href="#settings" class="menu-btn">
							<i class="fas fa-cog"></i>
							<span>Paramètres <i class="fas fa-chevron-down drop-down"></i></span>
						</a>
						<div class="sub-menu">
							<a href="modpasse.php"><i class="fas fa-lock"></i><span>Modifier votre mot de passe</span></a>
							<a href="changeprof.php"><i class="fas fa-language"></i><span>Modifier votre profil</span></a>
						</div>
					</li>
					
					
					
				</div>
			</div>
			<!--sidebar end-->
			
			
			
			
			<!--main container start-->
			<div class="main-container">
				
				<div class="card">
			<center>

				<div id="ccontainer">
         
		<div >
     <br>
     <br>
    
				<h1 style="text-align : center ; color:#1d6775;">Rendez-Vous: </h1>
        <br>
                 
               <form method="post" action="">
			  <div class="form-group center">
				<label for="user" style="font-weight: bold;color: #000000;">Date:</label><br> 
        <br>
				<input type="text" class="form-control" id="user" name="date" style="margin-top:5px;" required>
			  </div> <br/>
			  
			  <button type="submit" class="btn btn-default" name ="chercher"style="background:#7eced5;color:#fff;padding:7px">Chercher </button>
			    <br> <br> <br> 
				 <div class="form-group center"></div>
				
			  
			</form>
			
			
			
		</div>
		<?php
				
				if(isset ($_POST['chercher'])){
				       
					   @$date=$_POST["date"];
					   
					   $sql="SELECT * FROM seance WHERE date='$date' AND id_medecin=$_GET[id]";
					 
					  $query=mysqli_query($con,$sql);
					  ?>
					  <div>
			       	<h1 style="text-align : center ; color: #1d6775">les séances:</h1>
              <br>
					
			<table>
			    <tr style="padding: 133px; margin: 15px;">
			        <th>Nom de séance</th>
			        <th>Heurs</th>			        
			        <th>Action</th>
			    </tr>
					<?php
				         while ($row=mysqli_fetch_array($query)) {
						
				           ?>
						<tr>
						    <td><?php echo $row['nom_seance'] ?></td>
						    <td><?php echo $heur_sean=$row['heur'] ?></td>
							<?php
							$indis=$row['nombre'];
							
							 if($indis!=0){
							
							?>			
							<td>
							<form action="malek.php" method="post">							  
								                    <input type="image" src="works/malek.jpg" class="alert" name="etat"  width="40px" height="40px" />	
							                    	 <input type="hidden" name="hid" value="<?php echo $row['date']?>" />
								                     <input type="hidden" name="hidd" value="<?php echo $row['id_seance']?>" />
								                 <input type="hidden" name="hiddd" value="<?php echo $_GET['id']?>" />
								</form>
							</td>
							 <?php }else{?>
			             	<td style="color: red">Indisponible</td>	 
						</tr>
						<?php
							 }
				}?>
						</table>
<br/>
			 
					<?php
						}
				?>
			    
			<script src="mm.js"></script>
<script src="m.js"></script>			
				<script>
							
function bb(){
	swal({
	  icon: "success",
		 
						
						text :'Votre demande a été envoyée'
	})
	
}
</script>
		</div>  
			
				 <div class="wrapper" >
        <div class="calendar">
            <div class="month">
                <div class="prev" onclick="moveDate('prev')" >
                    <span>&#10094;</span>
                </div>
                <div>
                    <h2 id="month"></h2>
                    <br>
					
                    <p id="date_str"></p>
					<br/>
					<p id="malek"></p>
                </div>
                <div class="next" onclick="moveDate('next')">
                    <span>&#10095;</span>
                </div>
            </div>
            <div class="weekdays">
                <div onclick="malek()">Dimanche</div>
                <div>Lundi</div>
                <div>Mardi</div>
                <div>Mercredi</div>
                <div>Jeudi</div>
                <div>Vendredi</div>
                <div>Samedi</div>
            </div>

            <div class="days" >

            </div>
        </div>

   
	 </div>
		</div>
		</center>
					<p></p>
				</div>
			</div>
			<!--main container end-->
		</div>
		<!--wrapper end-->

		<script type="text/javascript">
		$(document).ready(function(){
			$(".sidebar-btn").click(function(){
				$(".wrapper").toggleClass("collapse");
			});
		});
		</script>
		 <script >
 var dt = new Date();
        function renderDate() {
            dt.setDate(1);
			
            var day = dt.getDay();
			
            var today = new Date();
			//endDate=31
            var endDate = new Date(
                dt.getFullYear(),
                dt.getMonth() + 1,
                0
            ).getDate();
            //prevDate=30
            var prevDate = new Date(
                dt.getFullYear(),
                dt.getMonth(),
                0
            ).getDate();
            var months = [
                "Janvier",
                "Février",
                "Mars",
                "Avril",
                "Mai",
                "Juin",
                "Juillet",
                "Aoùt",
                "Septembre",
                "Octobre",
                "Novembre",
                "Décembre"
            ]
            document.getElementById("month").innerHTML = months[dt.getMonth()];

            document.getElementById("date_str").innerHTML = today.toLocaleString("en-GB");
			var cells = "";
            for (x = day; x > 0; x--) {
                cells += "<div class='prev_date' >" + (prevDate - x + 1) + "</div>";
				
            } 
                    x = parseInt( today.getMonth() +1);
			        y = parseInt( today.getFullYear());
					
            for (i = 1; i <= endDate; i++) {
				if(i < today.getDate()&& dt.getMonth() == today.getMonth()){
					cells+="<div>" + i + "</div>"
				}
                else if (i == today.getDate() && dt.getMonth() == today.getMonth()){
					//m= parseInt(i);
					if(((x>=1)&&(x<10))  )
					{
					cells += "<div class='today' onclick= malek('" + y + "-" + x + "-" + i + "') >" + i + "</div>";	
					}else{
					cells += "<div class='today' onclick= malek('" + y + "-" + x + "-" +  i + "') >" + i + "</div>";
					}
					
				}
                else{ 
				m= parseInt(i);
				if((m>=1)&&(m<10))
					{
                    cells += "<div onclick= malek('"+y+"-"+x+"-"+"0"+m+ "')>" + i + "</div>";
					}else{
					 cells += "<div onclick= malek('"+y+"-"+x+"-"+m+ "')>" + i + "</div>";	
					}
				}
            }
			
            document.getElementsByClassName("days")[0].innerHTML = cells;
			

				
			}
           function malek(par){
			   document.getElementById("user").value = par ;
			   
						 
		   }
        

	

        function moveDate(para) {
            if(para == "prev") {
                dt.setMonth(dt.getMonth() - 1);
				  
            } else if(para == 'next') {
                dt.setMonth(dt.getMonth() + 1);
				
            }
            renderDate();
        }
		
		
	
    </script>

	</body>
</html>
