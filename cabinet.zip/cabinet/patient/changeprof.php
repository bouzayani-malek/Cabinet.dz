<?php
    session_start();
				 //db details
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'cabinet';

//Connect and select the database
$db =  mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<meta charset="utf-8">
		<title>Patient</title>
		
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.0-2/css/all.min.css">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" charset="utf-8"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
		
	</head>
	<body>

		<!--wrapper start-->
		<div class="wrapper">
			<!--header menu start-->
			<div class="header">
				<div class="header-menu">
					<div class="title"><span>PATIENT</span></div>
					<div class="sidebar-btn">
						<i class="fas fa-bars"></i>
					</div>
					<ul>
						
						
						<li><a href="../login.php"><i class="fas fa-power-off"></i></a></li>
					</ul>
				</div>
			</div>
			<!--header menu end-->
			
			
			
			<!--sidebar start-->
			<div class="sidebar">
				<div class="sidebar-menu">
				
				<?php 
				$con=mysqli_connect("localhost","root","");
                       
                        // Select the database to use
                        mysqli_select_db($con,'cabinet');
                     $result = mysqli_query($con,"SELECT * FROM infousers where id_info='".$_SESSION["patient"]."';") ;
					 while($row = mysqli_fetch_array($result)){
				?>
					<center class="profile">
						<img src="works/<?php echo $row['image']; ?>" alt="">
						<p><?php echo $row['nom']; ?></p>
					</center>
					
					 <?php }?>
				
					
					
					<li class="item" id="profile">
						<a href="#profile" class="menu-btn">
							<i class="fas fa-user-circle"></i>
							<span>Profil <i class="fas fa-chevron-down drop-down"></i></span>
						</a>
						<div class="sub-menu">
					
							<a href="profil.php"><i class="fas fa-address-card"></i><span>Votre profil</span></a>
						</div>
					</li>
					
					<li class="item" id="rend">
						<a href="#rend" class="menu-btn">
							<i class="fas fa-ambulance"></i>
							<span>Rendez-vous <i class="fas fa-chevron-down drop-down"></i></span>
						</a>
						<div class="sub-menu">
							<a href="vosrendezvous.php"><i class="fas fa-bible"></i><span>Vos rendez-vous</span></a>
	
						</div>
					</li>
					
					
					
					
					<li class="item" id="profi">
						<a href="#profi" class="menu-btn">
							<i class="fas fa-briefcase-medical"></i>
							<span>Prendre RDV<i class="fas fa-chevron-down drop-down"></i></span>
						</a>
						<div class="sub-menu">
							<a href="rdv.php"><i class="fas fa-male"></i><span>La liste des médecins</span></a>
							<a href="ord.php"><i class="fas fa-chevron-down drop-down"></i><span>Vos ordonnances</span></a>
							
						</div>
					</li>
					
					
					
					
					<li class="item" id="settings">
						<a href="#settings" class="menu-btn">
							<i class="fas fa-cog"></i>
							<span>Paramètres <i class="fas fa-chevron-down drop-down"></i></span>
						</a>
						<div class="sub-menu">
							<a href="modpasse.php"><i class="fas fa-lock"></i><span>Modifier votre mot de passe</span></a>
							<a href="changeprof.php"><i class="fas fa-language"></i><span>Modifier votre profil</span></a>
						</div>
					</li>
					
					
					
				</div>
			</div>
			<!--sidebar end-->
			
			
			
			
			<!--main container start-->
			<div class="main-container">
				
				<div class="card">
						
				<?php 
									
									
									//db details
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'cabinet';

//Connect and select the database
$db =  mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);

//selection du base de donner 
  $re="SELECT * FROM `infousers` WHERE id_info=$_SESSION[patient] ";
  $res=mysqli_query($db,$re);	
?>
				
				
				<center>
          <br>
          <br>
          <br>
								<br>
								<br>
								<br>
				 <h1 style="color: #1d6775">Modifier votre profil: </h1><br><br>
         <br>

                                <?php while ($lig=mysqli_fetch_array($res)){ ?>    
				       <form role="form"  name="medecin" method="post" action="" >
									<br>
                                        <div class="form-group">
                                            <h5 style="color:red;font-size: 15px;">Nom:</h5><br/>
                                            <input class="form-control" type="text"  value="<?php echo $lig['nom']; ?>"name="nom">                             
                                        </div>
                                        <br>
										
                                        <div class="form-group">
                                            <h5 style="color:red;font-size: 15px;">Prénom: </h5><br/>
                                            <input class="form-control" value="<?php echo $lig['prenom']; ?>  "type="text" name="prenom">                             
                                        </div>
                                        <br/>
										
										 <div class="form-group">
                                             <h5 style="color:red;font-size: 15px;">Téléphone: </h5><br/>
                                            <input class="form-control"type="text"value="<?php echo $lig['telephone']; ?>" name="telephone">                             
                                        </div>
                                        <br/>
										
										 <div class="form-group">
                                             <h5 style="color:red;font-size: 15px;">Adresse:</h5><br/>
                                            <input class="form-control"   value="<?php echo $lig['adresse']; ?>"type="text" name="adresse">                             
                                        </div>
                                        <br/>
										
										<div class="form-group">
                                             <h5 style="color:red;font-size: 15px;">Email:</h5><br/>
                                            <input class="form-control"  value="<?php echo $lig['email']; ?>"type="text" name="email">                             
                                        </div>
                                        <br/>
                                           <div class="form-group">
                                             <h5 style="color:red;font-size: 15px;">Région:</h5><br/>
                                            <input class="form-control"  value="<?php echo $lig['region']; ?>"type="text" name="region">                             
                                        </div>
                                        <br/>
										
										<div class="form-group">
                                             <h5 style="color:red;font-size: 15px;">Image:</h5><br/>
                                            <input class=""  type="file" name="image">                             
                                        </div>
										<br/>
										
                                        <button type="submit" class="btn btn-default" name="ajouter " style="color: #fff;background:#7eced5">Modifier</button>
                                        </center>
										
                                    </form>
								<?php }
									if($_POST){
									$nom=$_POST["nom"];
									$prenom=$_POST["prenom"];
									$telephone=$_POST["telephone"];
									$adresse=$_POST["adresse"]; 
									$email=$_POST["email"];
                                     $region=$_POST["region"];
								    $image =$_POST["image"];
				      									 
									 $SQL="UPDATE `infousers` SET `nom`='$nom',`prenom`='$prenom',`adresse`='$adresse',`email`='$email',`image`='$image',`telephone`='$telephone',`region`='$region' WHERE id_info=$_SESSION[patient]";
		                     
    mysqli_query($db,$SQL); 
                                         }			?>
				
				</center>
									
							
					<p></p>
				</div>
			</div>
			<!--main container end-->
		</div>
		<!--wrapper end-->

		<script type="text/javascript">
		$(document).ready(function(){
			$(".sidebar-btn").click(function(){
				$(".wrapper").toggleClass("collapse");
			});
		});
		</script>

	</body>
</html>
