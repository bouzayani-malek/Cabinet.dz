<?php
ob_start();
    session_start();


	$msg="";
	if ($_SERVER["REQUEST_METHOD"] == "POST"){
                $Name=$_POST["phuname"];
				$Prenom=$_POST["prenom"];
	            $Password=$_POST["phpass"];
				$Passwor=$_POST["phpas"];
	            $Email=$_POST["phemail"];
	            $Mobile=$_POST["phmobile"];
	            $Address=$_POST["phaddress"];
                $image= $_POST["image"];  
				$id_spe=$_POST['carar'];
				
                	if( $Password != $Passwor){
   	                  	$msg="The two passwords do not match";
						// header("Location:signup.php");
						 ob_end_flush();
                         	}else {

	            $conn=mysqli_connect("localhost","root","","cabinet");
	               
               $password = md5($Password);
			   //select id_ad
			   
			   $query1 = "SELECT * FROM admin";
   		       $resut2 = mysqli_query($conn,$query1);
			   $ro= mysqli_fetch_array($resut2);
			   
               $sql1="insert into medecin( `nom`, `prenom`, `telephone`, `adresse`, `email`, `passe`, `image`, `id_spe`, `id_ad`) values('$Name','$Prenom', $Mobile,'$Address','$Email','$password' ,'$image',$id_spe,$ro[id_ad])";
	           //echo $sql1;
               $result1= mysqli_query($conn,$sql1)or die(mysqli_error($conn));
			   
			   
                $_SESSION["upass"]= $password;
				$query = "SELECT * FROM medecin WHERE nom ='$Name' AND passe ='$password'";
   		        $result2 = mysqli_query($conn,$query);
   		        $row= mysqli_fetch_array($result2);
		        if($row["nom"]==$Name && $row["passe"]==$password)
                  {
						$_SESSION["id"]=$row["id_medecin"];
						$_SESSION["name"]=$row["nom"] ;
				  }
				  $_SESSION["malek"]=1;
			   header("Location:medecin/profilmed.php");
			   
                   ob_end_flush();
							}   
            }
?>
<!DOCTYPE html>
 
<html>
<head>
	
	<title>Inscription médecin</title>
	<style type="text/css">
		body{
		background: url(works/Medical-Tourism-2019.jpg) no-repeat center center fixed; 
           -webkit-background-size: cover;
           -moz-background-size: cover;
           -o-background-size: cover;
           background-size: cover;
		}
	</style>
</head>


<body>
	
	<section >
		
		
		
		
		<div > 
    
            <br>
            
          
            
			<form  action="" method="post" style="margin: 2%;background-color:#0b7285;border: 1px #e3e8ef;border-radius: 5%; opacity:0.9;text-align: center;margin-left: 30%;margin-right: 30%;padding-top: 2%;padding-bottom: 2%;box-shadow: 5px 10px #989ba0;">
				<br>
				<br>
			 <?php 
				
					echo '<p style="font-weight: bold;color: red;">'.$msg.'</p>';
				
				?>

                <div >
				<label for="user" style="font-weight: bold;color: #000000;font-size: 17px;">Nom:</label>
				<input type="text" id="user" name="phuname" style="width:50%;margin-left: 27%" placeholder="Votre nom" required>
			  </div>
            <br/>
			  <div >
				<label for="prenom" style="font-weight: bold;color: #000000;font-size: 17px;">Prénom:</label>
				<input type="text"  id="prenom" name="prenom" style="width:50%;margin-left: 23%" placeholder=" Votre Prénom" required>
			  </div><br/>
			  <div >
				<label for="email" style="font-weight: bold;color: #000000;font-size: 17px;">Email:</label>
				<input type="email"id="email" name="phemail" style="width:50%;margin-left: 25%" placeholder="Email" required>
			  </div><br/>
			 
			  <div >
				<label for="mbl" style="font-weight: bold;color: #000000;font-size: 17px;">Numéro de téléphone:</label>
				<input type="text"  id="mbl"  name="phmobile"  placeholder="Numéro de téléphone"style="width:50%;margin-left: 5%" required>
			  </div><br/>
			  <div >
				<label for="adrs" style="font-weight: bold;color: #000000;font-size: 17px;">Adresse:</label>
				<input type="text"  id="adrs" name="phaddress"  placeholder="Adresse"style="width:50%;margin-left: 23%" required>
			  </div>
			  <br/>
			  
                <div >
				<label for="pwd" style="font-weight: bold;color: #000000;font-size: 17px;">Mot de passe:</label>
				<input type="password"  id="pwd" name="phpass" style="width:50%;margin-left: 16%" placeholder="********" required>
                </div><br/>
				 <div >
				<label for="pwd" style="font-weight: bold;color: #000000;font-size: 17px;">Confirmation:</label>
				<input type="password"  id="pwd1" name="phpas" style="width:50%;margin-left: 16%" placeholder="*******" required>
                </div><br/>
			  <div >
				<label for="adrs" style="font-weight: bold;color: #000000;font-size: 17px;">Image :</label>
				<input type="file" id="imag" name="image" style="width:50%;margin-left: 27%" >
			  </div><br/>
			  <div class="form-group">
			  <?php 
			  
			  				 //db details
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'cabinet';

//Connect and select the database
$db =  mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);

//selection du base de donner 
  $requet ="SELECT * FROM `specialite`";
				
                       
            $result=mysqli_query($db,$requet);	
			  ?>
			  
				<label for="adrs" style="font-weight: bold;color: #000000;font-size: 17px;">Spécialité:</label><br/>
				<br>
				 <select name="carar" type="select" > 
										
                                      <?php while ($line=mysqli_fetch_array($result)){?>
                                      <option value="<?php echo $line['id_spe']; ?>"><?php echo $line['nom_spe']; ?></option>
                                      <?php }?>
                 </select>
			  </div>
			  <br>






             
			  
			  <br/>
			  <button type="submit" style="font-weight: bold;background-color: #1d6775;color:#fff;">Inscrire</button>
               <br>
			  <br>
             <a href="index.php"> <label  style="font-weight: bold;color: red;font-size: 17px;">retour</label></a>
			  
			 
			 
			</form>
           
			
             
		</div>
		</section>

</body>
</html>