<?php
    session_start();
?>
<!DOCTYPE html>
 
<html>
<head>
	
	<title>Connnexion</title>
	<style type="text/css">
		body{
		background: url(works/Medical-Tourism-2019.jpg) no-repeat center center fixed; 
           -webkit-background-size: cover;
           -moz-background-size: cover;
           -o-background-size: cover;
           background-size: cover;
		}
	</style>
</head>


<body>
	
	<section >
		
		
		
		
		<div > 
    
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
           
            
			<form  action="mam.php" method="post" style="margin: 2%;background-color:#0b7285;border: 1px #e3e8ef;border-radius: 5%; text-align: center;margin-left: 30%; opacity: 0.9; margin-right: 30%;padding-top: 2%;padding-bottom: 2%;box-shadow: 5px 10px #989ba0;">
			 		<?php $msg="";
				if(isset($_GET['er'])){
					$msg="votre email ou mot de  passe est incorrect";
					echo '<p style="font-weight: bold;color: red; font-size: 17px;">'.$msg.'</p>';
				}
				
				?>
				<br>
				<br>
			 <div >
				<label for="uname" style="font-weight: bold;color: #000000; font-size: 17px;">Email:</label>
				<input type="text" id="email" name="name" style="width:50%;margin-left: 17%;" placeholder="Votre email" required>
			  </div><br>
			  <br>
			  <div>
				<label for="pwd" style="font-weight: bold;color: #000000;font-size: 17px;">Mot de passe:</label>
				<input type="password"  id="pwd" name="pass" style="width:50%;margin-left:7%" placeholder="****"required>
			  </div>
			  <br>
			  <br>
			  <table border="0" width="100%">
               
                  <tbody>
                   <tr>
                     <td> <button type="submit" name="medecin" style="font-weight: bold;background: #1d6775;color: #fff;margin-left:1%;">Connexion médecin</button>
                     </td>
                      <td> <button type="submit" name ="admin" style="font-weight: bold;background: #1d6775;color: #fff;margin-left:1%;">Connexion admine</button>
                     </td>
                   </tr>
                    <tr>
                     <td><a href="inscritmed.php"> <label  style="font-weight: bold;color: #000; font-size: 17px; "> Créer un compte</label></a>
                      </td>
                      <td><a href="inscrit.php"> <label  style="font-weight: bold;color: #000;font-size: 17px;"> Créer un compte</label></a>
                     </td>
                   </tr> <tr>
                     <td><a href="motpassemed.php"> <label  style="font-weight: bold;color: red;">mot de  passe oublié </label></a>
                      </td>
                      <td><a href="passead.php"> <label  style="font-weight: bold;color: red;">mot de  passe oublié </label></a>
                     </td>
                   </tr>
				
                    
                 </tbody>
			    
             
			  
			
			 </table>
			 
			</form>
            
			
             
		</div>
		</section>

</body>
</html>