 <?php
session_start();
					
																										//db details
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'cabinet';

//Connect and select the database
$db =  mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
	                               $delete=$_POST['etatt'];
									
								    	$S="DELETE FROM `rdv` WHERE id_info=$delete";
			                            mysqli_query($db,$S);
										$SQ="DELETE FROM `message` WHERE id_info=$delete";
			                            mysqli_query($db,$SQ);
										$SQLH="DELETE FROM `ordonnance` WHERE id_info=$delete";
			                            mysqli_query($db,$SQLH);
										$SQL="DELETE FROM `infousers` WHERE id_info=$delete";
			                            mysqli_query($db,$SQL);
										header("location:malademed.php");
							
					 
				?>