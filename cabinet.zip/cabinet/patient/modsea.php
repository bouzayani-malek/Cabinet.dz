<?php
ob_start();
    session_start();
				 //db details
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'cabinet';

//Connect and select the database
$db =  mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<meta charset="utf-8">
		<title>Patient</title>
		
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.0-2/css/all.min.css">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" charset="utf-8"></script>
		<link rel="stylesheet" type="text/css" href="style.css">
		
	</head>
	<body>

		<!--wrapper start-->
		<div class="wrapper">
			<!--header menu start-->
			<div class="header">
				<div class="header-menu">
					<div class="title"><span>PATIENT</span></div>
					<div class="sidebar-btn">
						<i class="fas fa-bars"></i>
					</div>
					<ul>
						
						
						<li><a href="../login.php"><i class="fas fa-power-off"></i></a></li>
					</ul>
				</div>
			</div>
			<!--header menu end-->
			
			
			
			<!--sidebar start-->
			<div class="sidebar">
				<div class="sidebar-menu">
				
				<?php 
				$con=mysqli_connect("localhost","root","");
                       
                        // Select the database to use
                        mysqli_select_db($con,'cabinet');
                     $result = mysqli_query($con,"SELECT * FROM infousers where id_info='".$_SESSION["patient"]."';") ;
					 while($row = mysqli_fetch_array($result)){
				?>
					<center class="profile">
						<img src="works/<?php echo $row['image']; ?>" alt="">
						<p><?php echo $row['nom']; ?></p>
					</center>
					
					 <?php }?>
				
					
					
					<li class="item" id="profile">
						<a href="#profile" class="menu-btn">
							<i class="fas fa-user-circle"></i>
							<span>Profil <i class="fas fa-chevron-down drop-down"></i></span>
						</a>
						<div class="sub-menu">
					
							<a href="profil.php"><i class="fas fa-address-card"></i><span>Votre profil</span></a>
						</div>
					</li>
					
					<li class="item" id="rend">
						<a href="#rend" class="menu-btn">
							<i class="fas fa-ambulance"></i>
							<span>Rendez-vous <i class="fas fa-chevron-down drop-down"></i></span>
						</a>
						<div class="sub-menu">
							<a href="vosrendezvous.php"><i class="fas fa-bible"></i><span>Vos rendez-vous </span></a>
	
						</div>
					</li>
					
					
					
					
					<li class="item" id="profi">
						<a href="#profi" class="menu-btn">
							<i class="fas fa-briefcase-medical"></i>
							<span>Prendre un RDV<i class="fas fa-chevron-down drop-down"></i></span>
						</a>
						<div class="sub-menu">
							<a href="rdv.php"><i class="fas fa-male"></i><span>La liste des médecins</span></a>
													<a href="ord.php"><i class="fas fa-chevron-down drop-down"></i><span> Vos ordonnances</span></a>
	
						</div>
					</li>
					
					
					
					
					<li class="item" id="settings">
						<a href="#settings" class="menu-btn">
							<i class="fas fa-cog"></i>
							<span>Paramètres <i class="fas fa-chevron-down drop-down"></i></span>
						</a>
						<div class="sub-menu">
							<a href="modpasse.php"><i class="fas fa-lock"></i><span>Modifier votre mot de passe</span></a>
							<a href="changeprof.php"><i class="fas fa-language"></i><span>Modifier votre profil</span></a>
						</div>
					</li>
					
					
					
				</div>
			</div>
			<!--sidebar end-->
			
			
			
			
			<!--main container start-->
			<div class="main-container">
				
				<div class="card">
			

				<br/><br/>
				<br>
								<br>
								<br>
								<br>
				
				<?php 
									
				//db details
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'cabinet';

//Connect and select the database
$db =  mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);


//selection du base de donner 
  $re="SELECT * FROM `seance` WHERE date='$_GET[id]' AND id_medecin='$_GET[idd]' AND nombre!=0 ";
  $res=mysqli_query($db,$re);		?>
				<center>
				 <h1 style="color: #1d6775;">Modifier séance de rendez-vous :</h1><br><br>
				 <br>
				 <br>
				 <br>
                                  
				       <form role="form"  name="medecin" method="post" action="" >
									
                                        <div class="form-group">
                                            <h5 style="color:red;font-size:17px; ">Séance: </h5><br/> <br>
                <br>
				 <select name="carar" type="select" style="font-size: 30px;" > 
										
                                                <?php while ($lig=mysqli_fetch_array($res)){ ?> 
                                           <option style="font-size: 30px; " value="<?php echo $lig['id_seance']; ?>"><?php echo $lig['nom_seance']; ?></option>
										   
                                            <?php }?>
                                         </select> </div>
										<br/>
										<br>
                                        
										 
										
                                        <button type="submit" class="btn btn-default" name="ajouter " style="color: #fff; background:#7eced5">Modifier</button>
                                        </center>
										
                                    </form>
								  <?php 
									
	
                          	if($_POST){ 
								    
									$seance=$_POST["carar"];
									 $SQL="UPDATE `rdv` SET `id_seance`=$seance WHERE id_rdv=$_GET[i]";
			                         mysqli_query($db,$SQL); 
                                     header("location:vosrendezvous.php");
									 ob_end_flush();
								}
									
									
									
									?>
				
				</center>
									
							
				</div>
			</div>
			<!--main container end-->
		</div>
		<!--wrapper end-->

		<script type="text/javascript">
		$(document).ready(function(){
			$(".sidebar-btn").click(function(){
				$(".wrapper").toggleClass("collapse");
			});
		});
		</script>

	</body>
</html>
