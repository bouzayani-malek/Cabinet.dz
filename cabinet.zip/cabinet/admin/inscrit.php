<?php
    session_start();
?>
<!DOCTYPE html>
 
<html>
<head>
	
	<title>Inscription admine</title>
	<style type="text/css">
		body{
		background: url(works/Medical-Tourism-2019.jpg) no-repeat center center fixed; 
           -webkit-background-size: cover;
           -moz-background-size: cover;
           -o-background-size: cover;
           background-size: cover;
		}
	</style>
</head>


<body>
	
	<section >
		
		
		
		
		<div > 
    
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            
            
            
			<form  action="" method="post" style="margin: 2%; background-color:#0b7285;border: 1px #e3e8ef;border-radius: 5%; opacity:0.9;text-align: center;margin-left: 30%;margin-right: 30%;padding-top: 2%;padding-bottom: 2%;box-shadow: 5px 10px #989ba0;">
				<br>
				<br>
			  <div >
				<label for="uname" style="font-weight: bold;color: #000000; font-size: 17px;">Email:   </label>
				<input type="text" id="email" name="name" style="width:50%;margin-left: 17%;" placeholder="Votre email" required>
			  </div><br>
			  <br>
			  <div>
				<label for="pwd" style="font-weight: bold;color: #000000; font-size: 17px;">Mot de passe:</label>
				<input type="password"  id="pwd" name="pass" style="width:50%;margin-left:8%" placeholder="****"required>
			  </div>
			  <br>
			  <br>
			  
			  
			  <button type="submit" style="font-weight: bold;background-color: #1d6775;color: #fff;">Inscrire</button>
               <br>
			  <br>
             <a href="index.php"> <label  style="font-weight: bold;background: #1d6775;color: red;font-size: 17px">Retour</label></a>
			  
			 
			 
			</form>
            <?php
                if ($_SERVER["REQUEST_METHOD"] == "POST")
                {   
                    
                    $username = $_POST["name"];
                    $password = md5($_POST["pass"]);
                    
                       $conn=mysqli_connect("localhost","root","","cabinet");
                     
                       $sql1="insert into `admin`(`user`, `passe`) values('$username','$password')";

                       $result1= mysqli_query($conn,$sql1)or die(mysqli_error($conn));
                   
                            
				$_SESSION["uname"]= $Name;
                $_SESSION["upass"]= $password;
				$query = "SELECT * FROM admin WHERE user ='$username' AND passe ='$password'";
   		        $result2 = mysqli_query($conn,$query);
   		        $row= mysqli_fetch_array($result2);
		        if($row["user"]==$username && $row["passe"]==$password)
                  {
						$_SESSION["medecin"]=$row["id_ad"];
				  }
				  $_SESSION["malek"]=1;
			   header("Location:profil.php");
                   //ob_end_flush();
							}   
                      

                        
                
            ?>
			
			
             
		</div>
		</section>

</body>
</html>